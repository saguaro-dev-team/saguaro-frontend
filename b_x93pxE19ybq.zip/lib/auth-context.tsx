'use client'

import { createContext, useContext, useState, useCallback, type ReactNode } from 'react'
import type { User, UserRole } from './store-types'

interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  isAdmin: boolean
  login: (email: string, password: string) => Promise<boolean>
  register: (data: RegisterData) => Promise<boolean>
  logout: () => void
}

interface RegisterData {
  email: string
  password: string
  nombre: string
  apellido: string
  telefono?: string
}

const AuthContext = createContext<AuthContextType | null>(null)

// Mock users for demonstration
const mockUsers: (User & { password: string })[] = [
  {
    id: '1',
    email: 'admin@saguaro.cl',
    password: 'admin123',
    nombre: 'Admin',
    apellido: 'Saguaro',
    role: 'administrador',
    fechaRegistro: new Date('2024-01-01'),
  },
  {
    id: '2',
    email: 'cliente@example.com',
    password: 'cliente123',
    nombre: 'Juan',
    apellido: 'Perez',
    telefono: '+56912345678',
    role: 'cliente',
    fechaRegistro: new Date('2024-06-15'),
  },
]

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)

  const isAuthenticated = user !== null
  const isAdmin = user?.role === 'administrador'

  const login = useCallback(async (email: string, password: string): Promise<boolean> => {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 500))

    const foundUser = mockUsers.find(u => u.email === email && u.password === password)
    
    if (foundUser) {
      const { password: _, ...userWithoutPassword } = foundUser
      setUser(userWithoutPassword)
      return true
    }
    
    return false
  }, [])

  const register = useCallback(async (data: RegisterData): Promise<boolean> => {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 500))

    // Check if email already exists
    if (mockUsers.some(u => u.email === data.email)) {
      return false
    }

    const newUser: User = {
      id: String(mockUsers.length + 1),
      email: data.email,
      nombre: data.nombre,
      apellido: data.apellido,
      telefono: data.telefono,
      role: 'cliente',
      fechaRegistro: new Date(),
    }

    mockUsers.push({ ...newUser, password: data.password })
    setUser(newUser)
    return true
  }, [])

  const logout = useCallback(() => {
    setUser(null)
  }, [])

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        isAdmin,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
