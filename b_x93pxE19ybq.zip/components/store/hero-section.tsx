import Link from 'next/link'
import Image from 'next/image'
import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-primary">
      <div className="mx-auto max-w-7xl">
        <div className="relative z-10 pb-8 sm:pb-16 md:pb-20 lg:w-full lg:max-w-2xl lg:pb-28 xl:pb-32">
          <div className="mx-auto max-w-7xl px-4 pt-10 sm:pt-12 md:pt-16 lg:pt-20 xl:pt-28">
            <div className="sm:text-center lg:text-left">
              <span className="inline-block rounded-full bg-primary-foreground/20 px-4 py-1.5 text-sm font-medium text-primary-foreground mb-4">
                Nueva Coleccion 2024
              </span>
              <h1 className="text-4xl font-bold tracking-tight text-primary-foreground sm:text-5xl md:text-6xl text-balance">
                <span className="block">Camina Natural</span>
                <span className="block text-primary-foreground/80">Vive Libre</span>
              </h1>
              <p className="mt-3 text-base text-primary-foreground/80 sm:mx-auto sm:mt-5 sm:max-w-xl sm:text-lg md:mt-5 md:text-xl lg:mx-0 text-pretty">
                Descubre el calzado barefoot que te permite reconectar con el movimiento
                natural de tus pies. Comodidad, salud y estilo en cada paso.
              </p>
              <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start gap-3">
                <Button
                  size="lg"
                  className="bg-primary-foreground text-primary hover:bg-primary-foreground/90"
                  asChild
                >
                  <Link href="/categoria/hombre">
                    Explorar Coleccion
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="mt-3 sm:mt-0 border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10"
                  asChild
                >
                  <Link href="/nosotros">Conoce Saguaro</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative background */}
      <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2">
        <div className="h-56 w-full bg-gradient-to-br from-primary to-primary/80 sm:h-72 md:h-96 lg:h-full lg:w-full flex items-center justify-center">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/saguaro_logo-tE5gHhhbTqxTolGTB4D1n3QrzCEVf4.jpg"
            alt="Saguaro Barefoot"
            width={400}
            height={400}
            className="w-48 h-48 md:w-64 md:h-64 lg:w-80 lg:h-80 object-contain opacity-30"
          />
        </div>
      </div>
    </section>
  )
}
